package com.example.demo.operations;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class User {
	@Id

	private int idno;
	private String name;
	private double percentage;
	private int backlogs;
	private String status ;
	
	public User() {
		
	}
	
	
	public User(int idno, String name, double percentage, int backlogs, String status) {
		super();
		this.idno = idno;
		this.name = name;
		this.percentage = percentage;
		this.backlogs = backlogs;
		this.status = status;
	}


	public int getIdno() {
		return idno;
	}
	public void setIdno(int idno) {
		this.idno = idno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	public int getBacklogs() {
		return backlogs;
	}
	public void setBacklogs(int backlogs) {
		this.backlogs = backlogs;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "User [idno=" + idno + ", name=" + name + ", percentage=" + percentage + ", backlogs=" + backlogs
				+ ", status=" + status + "]";
	}
		

}
