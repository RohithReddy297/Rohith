package com.example.demo.operations;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RequestMapping("/User")
@RestController
public class UserController {
	
	@Autowired
	
	private UserRepository UserRepository;
    
	@PostMapping("/add")
	public User add(@RequestBody User User)
	{
		return UserRepository.save(User);
		
	}
    
    @GetMapping("/all")
    public List<User> Users()
    {
    	return UserRepository.findAll();
    }
    @GetMapping("/{id}")
    public User GetUser(@PathVariable("id") int id)
    {
    	return UserRepository.findById(id);
    }
    @GetMapping("/find/{name}")
    public User GetUser(@PathVariable("name") String name)
    {
    	return UserRepository.findByName(name);
    }    
    @PutMapping("/operation/{id}")
	public User update(@PathVariable Integer id, @Validated @RequestBody User locationreport)
	{
		if(UserRepository.findById(id).isPresent())
		{
			return UserRepository.save(locationreport);
		}
		return null;
	}
    @DeleteMapping("/operation/{id}")
	public String delete(@PathVariable Integer id)
	{
    	UserRepository.deleteById(id);
		return "Succ";
		
	}
 }
