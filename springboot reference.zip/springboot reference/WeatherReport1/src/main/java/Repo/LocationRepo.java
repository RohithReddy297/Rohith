package Repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import Model.LocationReport;

@Repository

public interface LocationRepo extends JpaRepository<LocationReport, Integer>{
	@Query(value = "select * from Report", nativeQuery = true)
	List<LocationReport> getAllRecord();
	@Query(value = "select * from Report WHERE temperature= 50 ", nativeQuery = true)
	List<LocationReport> getspecificRecord();


}
