package Controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Model.LocationReport;
import Repo.LocationRepo;
import Repo.UserdetailsRepo;


@RestController
@RequestMapping("/User")
public class UserLocationControl {
	
	@Autowired
	LocationRepo locationrepo;
	
	@GetMapping("/Home")
	public String Home()
	{
		return "Welocome to Home";
	}
	@GetMapping("/weatherreport/{location_id}")
	public Optional<LocationReport> getReport(@PathVariable Integer location_id)
	{
	return locationrepo.findById(location_id);
	}
	@Autowired
	UserdetailsRepo user;

}
